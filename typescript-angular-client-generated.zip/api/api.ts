export * from './burgers.service';
import { BurgersService } from './burgers.service';
export const APIS = [BurgersService];
